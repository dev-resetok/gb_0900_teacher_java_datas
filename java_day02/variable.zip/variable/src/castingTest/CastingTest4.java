package castingTest;

public class CastingTest4 {
	public static void main(String[] args) {
		System.out.println(Integer.parseInt("10") + 4);
		System.out.println(Double.parseDouble("3.5") + 2.5);
	}
}
