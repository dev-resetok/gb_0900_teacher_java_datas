package taskPractice3;

import java.util.ArrayList;

public class DBConnecter {
	public static ArrayList<Song> song = new ArrayList<Song>();
}
