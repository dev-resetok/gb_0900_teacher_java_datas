package taskPractice3;

public class Page {
	public static void main(String[] args) {
		Chart chart = new Chart();
		
	}
}
