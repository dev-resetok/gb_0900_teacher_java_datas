package taskPractice3;

public class Chart {
	
//	차트에 노래 추가
	
//	노래 제목으로 검색
	
//	노래 장르로 검색
	
//	가수 이름으로 검색
	
//	노래 장르 수정
	
//	차트에서 노래 삭제
	
}
