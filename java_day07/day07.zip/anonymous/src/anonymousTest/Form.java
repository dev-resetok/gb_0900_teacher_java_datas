package anonymousTest;

public interface Form {
	public String[] getMenu();
	public void sell(String order);
}
