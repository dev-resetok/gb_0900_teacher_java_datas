package interfaceTest;

public class Tiger extends AnimalAdapter{
	@Override
	public void poop() {
		System.out.println("어흥");
	}
	
}
