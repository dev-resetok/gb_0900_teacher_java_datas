package markerTest;

public class Cow extends Animal implements HerbivoreMarker{

}
