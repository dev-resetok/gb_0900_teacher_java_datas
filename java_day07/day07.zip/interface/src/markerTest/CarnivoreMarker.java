package markerTest;

// 육식동물
public interface CarnivoreMarker {;}
