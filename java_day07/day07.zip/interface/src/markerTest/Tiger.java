package markerTest;

public class Tiger extends Animal{

}
