package markerTest;

public class Bear extends Animal implements CarnivoreMarker{

}
