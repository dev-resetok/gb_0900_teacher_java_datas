package bank;

public class Kookmin extends Bank {

}
