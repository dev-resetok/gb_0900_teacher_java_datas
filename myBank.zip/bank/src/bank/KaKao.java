package bank;

public class KaKao extends Bank {

}
