package bank;

import java.util.Scanner;

public class ATM {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Bank bank = null;
		Bank[][] arBank = {
			new KaKao [100],
			new Shinhan [100],
			new Kookmin [100]
		};
		String[] banks = {"카카오뱅크", "신한은행", "국민은행"};
		String title = "통합 은행 어플에 오신 것을 환영합니다. 화면을 확인하신 후 이용하시려는 은행에 해당하는 번호를 눌러주십시오.\n1. 카카오뱅크\n2. 신한은행\n3. 국민은행";
		String message = "1. 계좌개설 \n2. 입금하기\n3. 출금하기\n4. 잔액조회\n5. 계좌번호 찾기(새로운 계좌발급, 핸드폰 번호로 서비스 이용가능)\n6. 나가기";
		String name = null, phone = null, password = null;
		int input = 0;
		
		while(true) {
			System.out.println(title);
			while(true) {
				input = sc.nextInt();
				if(input < 1 || input >3) {
					System.out.println("잘못된 번호를 입력하셨습니다. 다시 한 번 입력해주십시오.");
					continue;
				}
				break;
			}
			System.out.println("그럼" + banks[input-1] + "에서 진행하실 수 있는 서비스들을 안내해드릴테니 화면을 보시고 원하시는 서비스에 해당하는 번호를 눌러주십시오.");
			System.out.println(message);
			input = sc.nextInt();
			
			
			bank = new Bank(name, phone, password);
			
		}
	}
}
