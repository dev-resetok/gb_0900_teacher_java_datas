package bank;

import java.util.Random;

public class Bank {
//	*변수
//	예금주
	private String name;
//	계좌번호
	private String accountNum;
//	핸드폰번호
	private String phoneNum;
//	비밀번호
	private String password;
//	잔액(통장)
	private int balance;
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public Bank() {;}
	
	public Bank(String name, String phoneNum, String password) {
		String number = "";
		int count = 6;
		Random random = new Random();
		
		for (int i = 0; i < count; i++) {
			number += random.nextInt(count) + "";
		}
		this.name = name;
		this.accountNum = number;
		this.phoneNum = phoneNum;
		this.password = password;
	}
	
//	*메소드
//	계좌번호 중복검사
	boolean checkAccount(Bank[] arBank, String account) {
		boolean overlap = false;
		for (int i = 0; i < arBank.length; i++) {
			if(arBank[i].accountNum == account) {
				overlap = !overlap;
				return overlap;
			}
		}
		
		return overlap;
	}
//	핸드폰번호 중복검사
	boolean checkPhone(Bank[] arBank, String phone) {
		boolean overlap = false;
		for (int i = 0; i < arBank.length; i++) {
			if(arBank[i].phoneNum == phone) {
				overlap = !overlap;
				return overlap;
			}
		}
		
		return overlap;
	}
//	로그인
	boolean isLogin(Bank[] arBank, String account, String password) {
		boolean pass = false;
		
		for (int i = 0; i < arBank.length; i++) {
			if(arBank[i].accountNum == account && arBank[i].password == password) {
				pass = !pass;
				return pass;
			}
		}
		
		return pass;
	}
//	입금
//	출금
//	잔액조회
}
