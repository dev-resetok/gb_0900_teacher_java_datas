package lambdaTask;

@FunctionalInterface
public interface OperCheck {
	public String[] getOpers(String expression);
}
