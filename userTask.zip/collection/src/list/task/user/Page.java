package list.task.user;

import list.task.DBConnecter;

public class Page {
	public static void main(String[] args) {
//		DBConnecter db = new DBConnecter();
		UserField userField = new UserField();
		
		userField.join("양승민", "yang123", "asdf12", "01012345678");
		userField.join("김범수", "beom123", "abc12", "01011112222");
		userField.join("박정현", "park123", "qwer12", "01012123588");
		userField.join("김나영", "kim123", "nayoung12", "01045612678");
		System.out.println(DBConnecter.users);
		System.out.println(userField.logIn("yang123", "asdf12").getName() + "님이 로그인 하셨습니다.");
		System.out.println(DBConnecter.users);
		System.out.println(DBConnecter.users);
		
	}
}
