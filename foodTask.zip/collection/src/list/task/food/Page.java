package list.task.food;

import list.task.DBConnecter;

public class Page {
	public static void main(String[] args) {
//		DBConnecter db = new DBConnecter();
		Restaurant restaurant = new Restaurant();
		Food ramen = new Food("라멘", 7_000, "일식");
		Food tangsuyuk = new Food("탕수육", 15_000, "중식");
		Food steak = new Food("스테이크", 18_000, "양식");
		Food sushi = new Food("모듬초밥", 12_000, "일식");
		Food bibimbap = new Food("비빔밥", 5_000, "한식");
		Food japchae = new Food("잡채", 4_000, "한식");
		
		restaurant.addFood(ramen);
		restaurant.addFood(tangsuyuk);
		restaurant.addFood(steak);
		restaurant.addFood(sushi);
		restaurant.addFood(bibimbap);
		restaurant.addFood(japchae);
//		System.out.println(db.foods);
		System.out.println(restaurant.checkKindByName("스테이크").getKind());
		System.out.println(restaurant.checkFoodsByKind("한식"));
		System.out.println("인상된 가격: " + restaurant.changeKindAndIncreaseCost("스테이크","한식").getPrice() + "원");
		System.out.println(restaurant.checkKindByName("스테이크").getKind());
		System.out.println(restaurant.checkFoodsCounts("한식"));
	}
}
//	밑에거가 쌤 코드

