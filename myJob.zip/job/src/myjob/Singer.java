package myjob;

import java.util.Random;

//0) 정보 보기
//이름: 
//잔고: 
//	default: 100만원
//  money < 0 ==> 파산(end this game)
//명성: 
//	default: 0
//	max: 100
//최근 음원차트 순위:
//	default: 200
//세간의 평가:
//	default: 듣보
//	components: 듣보, 가요계 종사자, 신용재 관상, 가왕(end this game), 사재기 가수
//	듣보: 기본
//	가요계 종사자: 최근 음원차트 순위 100위 이상 달성
//	신용재 관상: 최근 음원차트 순위 10위 이상 달성 & 콘서트 성공 이력 1회 이상
//	가왕: 최근 음원차트 순위 10위 이상 달성 && 콘서트 성공 이력 1회 이상 && 사재기 성공 이력 1회 이상
//	사재기 가수: 사재기 실패. 모든 평가 이력 초기화

//1) 음원 발매
//
//실행 시:
//	음원차트 200위권 진입
//		확률 29%
//		잔고 + 100만원
//		명성 + 1
//	음원차트 100위권 진입
//		확률 40%
//		잔고 + 200만원
//		명성 + 3	
//	음원차트 30위권 진입
//		확률 20%
//		잔고 + 800만원
//		명성 + 10
//	음원차트 10위권 진입
//		확률 10%
//		잔고 + 3000만원
//		명성 + 20
//	음원차트 1위
//		확률 1%
//		잔고 + 1억원
//		명성 + 40
//	
//2) 콘서트
//조건: 
//	실행 비용 3000만원
//	명성 80 이상
//	최근 음원차트 순위 10위 이상
//실행 시:
//	좌석 매진
//		확률 80%
//		명성 + 20
//		잔고 + 2억원
//	좌석 텅텅
//		확률 20%
//		명성 - 30
//		잔고 - 5000만원
//
//3) 사재기
//조건:
//	실행 비용 5000만원
//실행 시:
//	은밀하게 성공
//		확률 50%
//		명성 + 50
//	들킴
//		확률 50%
//		명성 -100
//
//4) 봉사활동
//조건: 
//	실행 비용 300만원
//실행 시:
//	성공
//		확률 90%
//			명성 + 4
//	실패
//		확률 10%
//			명성 - 30
//			보상 X
//
//5) 종료
//게임 종료(저장 X)

public class Singer {
	String name;
	int money;
	int fame;
	int rank;
	int reputation;

	public Singer(String name) {
		this.name = name;
		this.money = 1_000_000;
		this.rank = 0;
	}

	void checkInfo() {
		String message = "--------------사용자 정보--------------\n" + "이름: " + this.name + "\n" + "명성: " + this.fame + "\n";
		System.out.print(message);
	}

	int releaseMusic() {
		Random random = new Random();
		int[] arData = new int[100];
		int randomIndex = 0;

		for (int i = 29; i < 69; i++) {
			arData[i] = 1;
		}

		for (int i = 69; i < 89; i++) {
			arData[i] = 2;
		}

		for (int i = 89; i < 99; i++) {
			arData[i] = 3;
		}

		arData[99] = 4;

		randomIndex = random.nextInt(arData.length);

		return arData[randomIndex];
	}

	int holdConcert() {
		Random random = new Random();
		int[] arData = new int[10];
		int randomIndex = 0;

		if (this.money < 30_000_000)
			return 2;

		if (this.fame < 80)
			return 3;

		if (this.rank > 10)
			return 4;

		for (int i = 0; i < 8; i++) {
			arData[i] = 1;
		}

		randomIndex = random.nextInt(arData.length);

		return arData[randomIndex];
	}

	int cheat() {
		Random random = new Random();
		int[] arData = new int[10];
		int randomIndex = 0;

		if (this.money < 50_000_000)
			return 2;

		for (int i = 0; i < 5; i++) {
			arData[i] = 1;
		}

		randomIndex = random.nextInt(arData.length);

		return arData[randomIndex];
	}

	int volunteer() {
		Random random = new Random();
		int[] arData = new int[10];
		int randomIndex = 0;

		if (this.money < 3_000_000)
			return 2;

		for (int i = 0; i < 9; i++) {
			arData[i] = 1;
		}

		randomIndex = random.nextInt(arData.length);

		return arData[randomIndex];
	}

}
