package myjob;

import java.util.Scanner;

public class MyJobTest {
	public static void main(String[] args) {
		String title = "나도 가수다";
		String message = "0. 내 정보 조회하기\n1. 음원 발매하기\n2. 콘서트 개최하기\n3. 사재기 시도하기\n4. 봉사활동 다니기\n5. 게임 종료(저장 불가)";
		Scanner sc = new Scanner(System.in);
		String[] reputation = { "듣보", "가요계 종사자", "신용재 관상", "가왕", "사재기 가수" };
		Singer maroon5 = new Singer("Maroon5");
		String changedMoney = null;
		String initialRank = null;

		int choice = 0, concertCount = 0, cheatCount = 0;

		while (true) {
			System.out.println(title);
			System.out.println(message);
			choice = sc.nextInt();

			if (choice == 5) {
				System.out.println("게임이 종료되었습니다.");
				break;
			}

			if (maroon5.reputation == 3) {
				System.out.println("❤️축하드립니다~ " + maroon5 + "님께서 \"가왕\" 타이틀을 획득하셔서 게임이 종료됩니다.💜");
				System.out.println("❤️이 게임을 잘 클리어하신 만큼 " + maroon5 + "님께서는 어떤 난관을 마주하더라도 잘 헤쳐나가시리라 믿습니다.💜");
				System.out.println("❤️Good luck💜");
			}
			
			if (maroon5.money < 0) {
				System.out.println("😊아이고... 안타깝게도 " + maroon5.name + "님께서 파산하셔서 게임이 종료됩니다.😊");
				System.out.println("😊아닐 걸 알지만 다음에는 더 좋은 활약 기대하겠습니다.😊");
				System.out.println("😊분발하세요😊");
			}
			changedMoney = maroon5.money < 1_000_000 ? maroon5.money + "원"
					: maroon5.money < 100_000_000 ? maroon5.money / 10_000 + "만원" 
							: maroon5.money / 100_000_000 + "억원";
			maroon5.fame = maroon5.fame < 0 ? 0 
					: maroon5.fame > 100 ? 100 : maroon5.fame;
			initialRank = maroon5.rank == 0 ? "정보 없음" : maroon5.rank + "위";
			
			switch (choice) {
			case 0:
				System.out.println("사용자의 정보를 출력합니다.");
				maroon5.checkInfo();
				System.out.println("잔고: " + changedMoney + "\n" 
				+ "최근 음원차트 순위: " + initialRank + "\n" 
						+ "세간의 평가: " + reputation[maroon5.reputation] + "\n");
				break;
			case 1:
				System.out.println("음원 발매작업을 진행합니다.");
				switch (maroon5.releaseMusic()) {
				case 0:
					maroon5.money += 1_000_000;
					maroon5.fame++;
					maroon5.rank = 200;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 발매하신 음악이 lemon차트 200위권에 진입했습니다." 
								+ "\n보상:\n\t잔고 + 100만원\n\t명성 + 1\n");
					break;
				case 1:
					maroon5.money += 2_000_000;
					maroon5.fame += 3;
					maroon5.rank = 100;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 발매하신 음악이 lemon차트 100위권에 진입했습니다." 
								+ "\n보상:\n\t잔고 + 200만원\n\t명성 + 3\n");
					if(maroon5.reputation == 0) {
						maroon5.reputation = 1;
						System.out.println("\"가요계 종사자\" 타이틀 획득!");
						break;
					}
					break;
				case 2:
					maroon5.money += 8_000_000;
					maroon5.fame += 10;
					maroon5.rank = 30;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 발매하신 음악이 lemon차트 30위권에 진입했습니다." 
								+ "\n보상:\n\t잔고 + 800만원\n\t명성 + 10\n");
					if(maroon5.reputation == 0) {
						maroon5.reputation = 1;
						System.out.println("\"가요계 종사자\" 타이틀 획득!");
						break;
					}
					break;
				case 3:
					maroon5.money += 30_000_000;
					maroon5.fame += 20;
					maroon5.rank = 10;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 발매하신 음악이 lemon차트 10위권에 진입했습니다." 
								+ "\n보상:\n\t잔고 + 3000만원\n\t명성 + 20\n");
					if(maroon5.reputation == 0) {
						maroon5.reputation = 1;
						System.out.println("\"가요계 종사자\" 타이틀 획득!");
						break;
					}
					if(maroon5.reputation == 1 && concertCount >= 1) {
						maroon5.reputation = 2;
						System.out.println("\"신용재 관상\" 타이틀 획득!");
						break;
					}
					if(concertCount >= 1 && cheatCount >= 1) {
						maroon5.reputation = 3;
						System.out.println("\"가왕\" 타이틀 획득!");
						break;
					}
					break;
				case 4:
					maroon5.money += 100_000_000;
					maroon5.fame += 40;
					maroon5.rank = 1;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 발매하신 음악이 lemon차트 1위를 달성했습니다!!!" 
								+ "\n보상:\n\t잔고 + 1억원\n\t명성 + 40\n");
					if(maroon5.reputation == 0) {
						maroon5.reputation = 1;
						System.out.println("\"가요계 종사자\" 타이틀 획득!");
						break;
					}
					if(maroon5.reputation == 1 && concertCount >= 1) {
						maroon5.reputation = 2;
						System.out.println("\"신용재 관상\" 타이틀 획득!");
						break;
					}
					if(concertCount >= 1 && cheatCount >= 1) {
						maroon5.reputation = 3;
						System.out.println("\"가왕\" 타이틀 획득!");
						break;
					}
						
					break;
				}
				break;
			case 2:
				System.out.println("콘서트를 개최합니다.\n개최 비용: 3000만원");
				switch (maroon5.holdConcert()) {
				case 0:
					maroon5.money -= 80_000_000;
					maroon5.fame -= 30;
					System.out.println("안타깝네요... " 
							+ maroon5.name + "님이 개최한 콘서트에 파리만 날리면서 큰 적자를 보게 되셨습니다..." 
								+ "\n페널티:\n\t잔고 - 5000만원\n\t명성 - 30\n");
					break;
				case 1:
					maroon5.money += 170_000_000;
					maroon5.fame += 20;
					concertCount++;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 개최하신 콘서트가 전석 매진을 기록했습니다!!!" 
								+ "\n보상:\n\t잔고 + 2억원\n\t명성 + 20\n");
					if(maroon5.rank <= 10 && maroon5.reputation == 1) {
						maroon5.reputation = 2;
						System.out.println("\"신용재 관상\" 타이틀 획득!");
						break;
					}
					if(maroon5.rank <= 10 && cheatCount >= 1) {
						maroon5.reputation = 3;
						System.out.println("\"가왕\" 타이틀 획득!");
						break;
					}
					break;
				case 2:
					System.out.println("죄송합니다. 현재 이 서비스를 이용하실 수 없습니다.\n" 
							+ maroon5.name + "님이 보유하신 금액: " + changedMoney
								+ "\n콘서트 개최에 필요한 최소 금액: 3000만원\n ");
					break;
				case 3:
					System.out.println("죄송합니다. 현재 이 서비스를 이용하실 수 없습니다.\n" 
							+ maroon5.name + "님의 명성: " + maroon5.fame
								+ "\n콘서트 개최에 필요한 최소 명성: 80\n ");
					break;
				case 4:
					System.out.println("죄송합니다. 현재 이 서비스를 이용하실 수 없습니다.\n" 
							+ maroon5.name + "님의 최근 음원차트 순위: "+ initialRank 
								+ "\n콘서트 개최에 필요한 최소 순위: 10위\n ");
					break;
				}
				break;
			case 3:
				System.out.println("사재기를 시도합니다.\n시도 비용: 5000만원");
				switch (maroon5.cheat()) {
				case 0:
					maroon5.money -= 50_000_000;
					maroon5.fame -= 30;
					System.out.println("안타깝네요... " 
							+ maroon5.name + "님이 사재기를 시도하신 사실이 발각되어 큰 불명예를 안게 되셨습니다..." 
								+ "\n페널티:\n\t명성 - 30\n");
					if(maroon5.reputation != 4) {
						maroon5.rank = 0;
						concertCount = 0;
						cheatCount = 0;
						maroon5.reputation = 4;
						System.out.println("\"사재기 가수\" 타이틀 획득!");
					}
					break;
				case 1:
					maroon5.money -= 50_000_000;
					maroon5.fame += 50;
					cheatCount++;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님은 사재기를 통해 큰 명성을 얻는데 성공하셨습니다!!!" 
								+ "\n보상:\n\t명성 + 50\n");
					if(maroon5.rank <= 10 && concertCount >= 1) {
						maroon5.reputation = 3;
						System.out.println("\"가왕\" 타이틀 획득!");
						break;
					}
					break;
				case 2:
					System.out.println("죄송합니다. 현재 이 서비스를 이용하실 수 없습니다.\n" 
							+ maroon5.name + "님이 보유하신 금액: " + changedMoney
								+ "\n사재기 시도에 필요한 최소 금액: 5000만원\n ");
					break;
				}
				break;
			case 4:
				System.out.println("봉사활동을 실행합니다.");
				switch (maroon5.volunteer()) {
				case 0:
					maroon5.money -= 3_000_000;
					maroon5.fame -= 30;
					System.out.println("안타깝네요... " 
							+ maroon5.name + "님이 봉사활동 중에 짜증을 내는 모습이 녹화된 CCTV가 유출되어 큰 불명예를 안게 되셨습니다..." 
								+ "\n페널티:\n\t명성 - 30\n");
					break;
				case 1:
					maroon5.money -= 3_000_000;
					maroon5.fame += 4;
					System.out.println("축하드립니다~ " 
							+ maroon5.name + "님이 봉사활동을 다니며 선한 영향력을 행사하는 모습이 많은 사람들에게 귀감이 되고 있습니다!!!" 
								+ "\n보상:\n\t명성 + 4\n");
					break;
				case 2:
					System.out.println("죄송합니다. 현재 이 서비스를 이용하실 수 없습니다.\n" 
							+ maroon5.name + "님이 보유하신 금액: " + changedMoney
								+ "\n봉사활동 실행에 필요한 최소 금액: 300만원\n ");
					break;
				}
				break;
			}

		}

	}
}
