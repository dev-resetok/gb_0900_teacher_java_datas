package accessTest2;

import accessTest1.Access1;

public class AccessTest2 extends Access1 {
	public static void main(String[] args) {
//		Access1 access1 = new Access1();
		AccessTest2 accessTest2 = new AccessTest2();
	}
}
