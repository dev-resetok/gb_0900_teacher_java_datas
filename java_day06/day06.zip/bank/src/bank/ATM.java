package bank;

public class ATM {
	public static void main(String[] args) {
		
	}
}
