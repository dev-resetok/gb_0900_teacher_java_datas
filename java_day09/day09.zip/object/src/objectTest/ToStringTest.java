package objectTest;

import java.util.Random;

public class ToStringTest {
	public static void main(String[] args) {
		Random random = new Random();
		System.out.println(random);
		
//		Student 한동석 = new Student("한동석", 50);
//		Student 홍길동 = new Student("홍길동", 50);
//		
//		System.out.println(한동석);
//		System.out.println(홍길동);
	}
}
