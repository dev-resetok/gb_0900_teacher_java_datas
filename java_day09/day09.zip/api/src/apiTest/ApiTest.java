//package apiTest;
//
//public class ApiTest {
//	public static void main(String[] args) {
//		Calc calc = new Calc();
//		System.out.println(calc.divide(10, 3));
//	}
//}
