package exceptionTest;

public class ExceptionTest {
	public static void main(String[] args) {
//		int[] arData = new int[5];
//		
//		try {
//			arData[5] = 100;
//		} catch (ArrayIndexOutOfBoundsException e) {
//			System.out.println("인덱스를 확인해주세요!");
//		}
//		System.out.println("무조건 실행해야 하는 문장");
		
//		try {
//			System.out.println(10 / 0);
//		} catch (NumberFormatException e) {
//			System.out.println("0으로 나눌 수 없어요!");
//		} finally {
//			System.out.println("무조건 실행해야 하는 문장");
//		}
		
//		boolean test = true;
//		if(test) {
//			throw new BadWordException();
//		}
//		System.out.println("반드시 실행해야 하는 문장");
	}
}




















