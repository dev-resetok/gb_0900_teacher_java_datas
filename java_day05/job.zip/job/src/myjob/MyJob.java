package myjob;

public class MyJob {
	public static void main(String[] args) {
		
	}
}
