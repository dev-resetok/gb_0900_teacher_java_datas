package taskPractice;

public class Chart {

}
