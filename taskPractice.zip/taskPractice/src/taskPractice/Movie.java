package taskPractice;

import java.util.Objects;

public class Movie {
	private String name;
	private String genre;

	public Movie() {;}
	
	public Movie(Movie movie) {
		this(movie.getName(), movie.getGenre());
	}

	public Movie(String name, String genre) {
		super();
		this.name = name;
		this.genre = genre;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "제목: " + name + " 장르: " + genre;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		return name.equals(other.name);
	}

}
