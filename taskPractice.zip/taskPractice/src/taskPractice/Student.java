package taskPractice;

public class Student {

}
