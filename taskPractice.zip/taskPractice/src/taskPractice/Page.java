package taskPractice;

import database.DBConnecter;

public class Page {
	public static void main(String[] args) {
		Netflix netflix = new Netflix();
		Movie harryPotter = new Movie("해리포터", "판타지");
		Movie parasite = new Movie("기생충", "스릴러/코미디");
		Movie conan = new Movie("명탐정 코난", "애니메이션");
		Movie lucky = new Movie("럭키", "코미디");
		Movie annabelle = new Movie("애나벨", "스릴러");
		
		netflix.addMovie(harryPotter);
		netflix.addMovie(parasite);
		netflix.addMovie(conan);
		netflix.addMovie(lucky);
		netflix.addMovie(annabelle);
		System.out.println(DBConnecter.movies);
		System.out.println(netflix.checkMovie("기생충"));
		System.out.println(netflix.checkGenre("스릴러"));
		netflix.removeMovie("명탐정 코난");
		System.out.println(DBConnecter.movies);
		
	}
}
