package taskPractice;

import java.util.ArrayList;

import database.DBConnecter;

public class Netflix {
//	이렇게 쓰면 목적에 맞게 쓰는 것이 아니다. 누적된 데이터를 저장할 공간을 매번 다른 만들게 되는 것이기 때문이다.
//	DBConnecter db = new DBConnecter();
	
//	영화 추가
	public void addMovie(Movie movie) {
		DBConnecter.movies.add(movie);
	}
	
//	영화 삭제
	public void removeMovie(String name) {
		if(checkMovie(name) != null) {
			DBConnecter.movies.remove(checkMovie(name));
		}
	}
	
//	영화 제목으로 검색 / 중복 검사 알고리즘
	public Movie checkMovie(String name) {
		Movie movie = null;
	
		for (int i = 0; i < DBConnecter.movies.size(); i++) {
			if(DBConnecter.movies.get(i).getName().equals(name)) {
				movie = new Movie(DBConnecter.movies.get(i));
			}
		}
	
		return movie;
	}
//	영화 장르로 검색
	public ArrayList<Movie> checkGenre(String genre) {
		ArrayList<Movie> movies = new ArrayList<Movie>();
		
		for (int i = 0; i < DBConnecter.movies.size(); i++) {
			if(DBConnecter.movies.get(i).getGenre().contains(genre)) {
				movies.add(new Movie(DBConnecter.movies.get(i)));
			}
		}
		
		return movies;
	}
	
}
