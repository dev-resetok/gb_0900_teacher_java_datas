package taskPractice;

public class School {

}
