package taskPractice;

public class Music {

}
