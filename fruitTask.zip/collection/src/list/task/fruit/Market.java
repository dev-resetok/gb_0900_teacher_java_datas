package list.task.fruit;

import list.task.DBConnecter;

public class Market {
	
	public void addFruit(Fruit fruit, DBConnecter db) {
		db.fruits.add(fruit);
		System.out.println(fruit.getName() + " 추가 성공");
		System.out.println(db.fruits);
	}
	
	public void removeFruit(Fruit fruit, DBConnecter db) {
		if(db.fruits.remove(fruit)) {
			System.out.println(fruit.getName() + " 삭제 성공");
			System.out.println(db.fruits);
		} else {
			System.out.println(fruit.getName() + " 삭제 실패");
			System.out.println(db.fruits);
		}
	}
	
	public void checkFruitPrice(Fruit fruit, DBConnecter db) {
		int sum = 0;
		String resultMessage = null;
		
		for (int i = 0; i < db.fruits.size(); i++) {
			sum += db.fruits.get(i).getPrice();
		}
		resultMessage = fruit.getPrice() < sum/db.fruits.size() ? "입력하신 " + fruit.getName()
		+ "의 가격이 " + fruit.getPrice() + "원으로 과일들의 평균 가격인 " + sum/db.fruits.size() + "원보다 낮습니다." : "입력하신 " + fruit.getName()
		+ "의 가격이 " + fruit.getPrice() + "원으로 과일들의 평균 가격인 " + sum/db.fruits.size() + "원보다 높습니다." ;
		System.out.println(resultMessage);
	}
	
	public void showFruits(DBConnecter db) {
		System.out.println(db.fruits);
	}
	
	public void showPriceByName(Fruit fruit, DBConnecter db) {
		int index = 0;
		
		for (int i = 0; i < db.fruits.size(); i++) {
			if(fruit.getName().equals(db.fruits.get(i).getName()))
				index = i;
		}
		System.out.println(db.fruits.get(index).getName() + "의 가격은 " + db.fruits.get(index).getPrice() + "원입니다." );
	}
}

//	밑에거가 쌤 코드

//package list.task.fruit;
//
//import java.util.ArrayList;
//
//import list.task.DBConnecter;
//
//public class Market {
////   - 과일 이름으로 과일 조회
//   public Fruit checkFruitName(String name) {
//      Fruit fruit = null;
//      for (int i = 0; i < DBConnecter.fruits.size(); i++) {
//         if(DBConnecter.fruits.get(i).getName().equals(name)) {
//            fruit = DBConnecter.fruits.get(i);
//         }
//      }
//      return fruit;
//   }
//
////   - 과일 추가
//   public void add(Fruit fruit) {
//      DBConnecter.fruits.add(fruit);
//   }
//
////   - 과일 삭제
//   public void remove(Fruit fruit) {
//      DBConnecter.fruits.remove(fruit);
//   }
//   
////   - 과일 가격이 평균 가격보다 낮은 지 검사
//   public Fruit checkPrice(Fruit fruit) {
//      int total = 0;
//      double average = 0.0;
//      
//      for (int i = 0; i < DBConnecter.fruits.size(); i++) {
//         total += DBConnecter.fruits.get(i).getPrice();
//      }
//      
//      average = (double)total / DBConnecter.fruits.size();
//      
//      return fruit.getPrice() < average ? fruit : null;
//   }
//   
////   - 과일 전체 조회
//   public ArrayList<Fruit> findAll() {
//      return (ArrayList<Fruit>) DBConnecter.fruits.clone();
//   }
//   
//}
