//package list.task.fruit;
//
//import list.task.DBConnecter;

//public class Page {
//	public static void main(String[] args) {
//		DBConnecter dataBase = new DBConnecter();
//		Market market = new Market();
//		Fruit apple = new Fruit("사과", 5_000);
//		Fruit strawberry = new Fruit("딸기", 15_000);
//		Fruit banana = new Fruit("바나나", 25_000);
//		Fruit pineapple = new Fruit("파인애플", 35_000);
//		
//		market.addFruit(apple, dataBase);
//		market.addFruit(strawberry, dataBase);
//		market.addFruit(banana, dataBase);
//		market.addFruit(pineapple, dataBase);
//		market.removeFruit(pineapple, dataBase);
//		market.checkFruitPrice(pineapple, dataBase);
//		market.showFruits(dataBase);
//		market.showPriceByName(pineapple, dataBase);
//	}
//}

//	밑에거가 쌤 코드
package list.task.fruit;

import java.util.ArrayList;

//public class Page {
// public static void main(String[] args) {
//    Fruit melon = new Fruit("멜론", 15000);
//    Fruit apple = new Fruit("사과", 5000);
//    
//    Market market = new Market();
//    
//    if(market.checkFruitName(melon.getName()) == null) {
//       market.add(melon);
//    }
//    
//    if(market.checkFruitName(melon.getName()) == null) {
//       market.add(melon);
//    }
//    
//    if(market.checkFruitName(apple.getName()) == null) {
//       market.add(apple);
//    }
//    
//    ArrayList<Fruit> fruits = market.findAll();
//    System.out.println(fruits);
    
//    market.remove(apple);
//    
//    fruits = market.findAll();
//    System.out.println(fruits);
    
//    System.out.println(market.checkPrice(melon));
//    System.out.println(market.checkPrice(apple));
    
//    System.out.println(market.checkFruitName("멜론").getPrice());
    
// }
//}
