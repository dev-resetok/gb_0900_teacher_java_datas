package database;

import java.util.ArrayList;

import taskPractice.Movie;
import taskPractice.Music;
import taskPractice.Student;

public class DBConnecter {
	
//	외부에서 DBConnecter를 객체화할 수 없게 막아준다.
//	단 상속받은 자식 클래스에서는 사용할 수 있다.
//	그것도 싫으면 private으로 작성한다.
	protected DBConnecter() {;}
	
	public static ArrayList<Movie> movies = new ArrayList<Movie>();
	public static ArrayList<Student> students = new ArrayList<Student>();
	public static ArrayList<Music> musics = new ArrayList<Music>();
}
