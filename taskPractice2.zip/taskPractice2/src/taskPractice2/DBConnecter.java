package taskPractice2;

import java.util.ArrayList;

public class DBConnecter {
	public static ArrayList<Student> students = new ArrayList<Student>();
}
